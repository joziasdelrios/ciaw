function v = sz(s)
    v = s(3,:);
end
    