% Vector direction (versor)

function d = vecdir(u)
  d = u/norm(u);
end
