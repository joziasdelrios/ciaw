function v = sx(s)
    v = s(1,:);
end
    