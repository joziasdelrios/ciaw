function v = sy(s)
    v = s(2,:);
end
    