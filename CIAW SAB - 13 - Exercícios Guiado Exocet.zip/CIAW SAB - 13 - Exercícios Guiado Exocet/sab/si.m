function v = si(s, i)
    v = s(i,:);
end
    