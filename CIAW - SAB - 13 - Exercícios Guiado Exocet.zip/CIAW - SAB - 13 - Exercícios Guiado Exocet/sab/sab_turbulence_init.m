function turb = sab_turbulence_init()
    turb.vwii  = [0 0 0]';
    turb.vwiif = [0 0 0]';
    turb.uvw   = [0 0 0]';
end